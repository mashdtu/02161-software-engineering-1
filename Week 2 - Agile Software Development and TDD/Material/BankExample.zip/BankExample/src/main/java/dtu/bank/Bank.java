package dtu.bank;

import java.util.HashMap;
import java.util.Map;

public class Bank {

    private final Map<String, Account> accounts = new HashMap<>();

    // Registers a user and returns a unique account ID
    public String register(String userName, int initialBalance) {
        Account account = new Account(new User(userName), initialBalance);
        accounts.put(account.getAccountId(), account);
        return account.getAccountId();
    }

    // Withdraws an amount from the account
    public void withdraw(String accountId, int amount) throws BankException {
        checkForPositiveAmount(amount);
        var account = getAccount(accountId);
        int newBalance = account.getBalance() - amount;
        checkForSufficientFunds(newBalance);
        account.setBalance(newBalance);
    }

    private Account getAccount(String accountId) {
        return accounts.get(accountId);
    }

    // Deposits an amount into the account
    public void deposit(String accountId, int amount) throws BankException {
        checkForPositiveAmount(amount);
        var account = getAccount(accountId);
        account.setBalance(account.getBalance() + amount);
    }

    // Retrieves the balance of an account
    public int getBalance(String accountId) throws BankException {
        var account = getAccount(accountId);
        if (account == null) {
            throw new BankException("Invalid bank account number");
        }
        return account.getBalance();
    }

    // Transfers an amount from one account to another
    public void transfer(String senderAccountId, String recipientAccountId, int amount) throws BankException {
        checkForPositiveAmount(amount);
        int newBalance = getBalance(senderAccountId) - amount;
        checkForSufficientFunds(newBalance);
        withdraw(senderAccountId, amount);
        deposit(recipientAccountId, amount);
    }

    private void checkForSufficientFunds(int newBalance) throws BankException {
        if (newBalance < 0) {
            throw new BankException("Insufficient balance");
        }
    }

    private void checkForPositiveAmount(int amount) throws BankException {
        if (amount <= 0) {
            throw new BankException("Amount must be positive");
        }
    }
}