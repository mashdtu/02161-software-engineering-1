Feature: Managing Withdrawals in Bank Application
  As a bank user,
  I want to withdraw money from my account,
  So that my account balance is reduced accordingly.

  Scenario: User withdraws money successfully
    Given a registered user with an account balance of 1000
    When the user withdraws 200
    Then the account balance should be 800

  Scenario: Withdrawal by Bob does not affect Alice
    Given a registered user "Alice" with an account balance of 1000
    And a registered user "Bob" with an account balance of 500
    When the user "Bob" withdraws 50
    Then the account balance for "Alice" should be 1000
    And the account balance for "Bob" should be 450

  Scenario: Withdrawal of an amount larger than the balance
    Given a registered user "Alice" with an account balance of 100
    When "Alice" tries to withdraw 200
    Then an error should occur with the message "Insufficient balance"

  Scenario: Withdrawal of a negative amount gives an error
    Given a registered user "Alice" with an account balance of 100
    When "Alice" tries to withdraw -200
    Then an error should occur with the message "Amount must be positive"