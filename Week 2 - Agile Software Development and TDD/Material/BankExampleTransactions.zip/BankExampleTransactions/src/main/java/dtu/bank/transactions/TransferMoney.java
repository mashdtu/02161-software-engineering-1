package dtu.bank.transactions;

import java.util.Objects;

import dtu.bank.Bank;

public class TransferMoney extends Transaction {
    private final String from;
    private final int amount;
    private final String to;

    public TransferMoney(String from, int amount, String to) {
        this.from = from;
        this.amount = amount;
        this.to = to;
    }

    @Override
    public void updateBalance(Bank bank) {
    	bank.updateBalance(from, b -> b - amount);
    	bank.updateBalance(to, b -> b + amount);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        TransferMoney that = (TransferMoney) obj;
        return amount == that.amount && Objects.equals(from, that.from) && Objects.equals(to, that.to);
    }

    @Override
    public int hashCode() {
        return Objects.hash(from, amount, to);
    }


}