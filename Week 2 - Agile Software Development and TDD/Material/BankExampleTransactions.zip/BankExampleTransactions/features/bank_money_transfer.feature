Feature: Transferring Money Between Users
  As a bank user,
  I want to transfer money from my account to another user's account,
  So that the recipient's balance is updated and my balance is deducted.

  Scenario: User transfers money successfully
    Given a registered user "Alice" with an account balance of 1000
    And a registered user "Bob" with an account balance of 500
    When the user "Alice" transfers 200 to "Bob"
    Then the account balance for "Alice" should be 800
    And the account balance for "Bob" should be 700

  Scenario: Amount transferred must be positiv
    Given a registered user "Alice" with an account balance of 1000
    And a registered user "Bob" with an account balance of 500
    When the user "Alice" transfers -200 to "Bob"
    Then an error should occur with the message "Amount must be positive"
    And the account balance for "Alice" should be 1000
    And the account balance for "Bob" should be 500

  Scenario: Transfer cannot make a balance negative
    Given a registered user "Alice" with an account balance of 1000
    And a registered user "Bob" with an account balance of 500
    When the user "Alice" transfers 2000 to "Bob"
    Then an error should occur with the message "Insufficient balance"
    And the account balance for "Alice" should be 1000
    And the account balance for "Bob" should be 500
