Feature: Managing Deposits in Bank Application
  As a bank user,
  I want to deposit money into my account,
  So that my account balance is increased accordingly.

  Scenario: User deposits money into their account
    Given a registered user "Alice" with an account balance of 1000
    When the user "Alice" deposits 200
    Then the account balance for "Alice" should be 1200

  Scenario: The money deposited must be positive
    Given a registered user "Alice" with an account balance of 1000
    When the user "Alice" deposits -200
    Then an error should occur with the message "Amount must be positive"