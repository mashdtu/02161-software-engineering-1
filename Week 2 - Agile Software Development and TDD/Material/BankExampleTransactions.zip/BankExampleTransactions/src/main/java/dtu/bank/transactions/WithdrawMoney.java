package dtu.bank.transactions;

import java.util.Objects;

import dtu.bank.Bank;

public class WithdrawMoney extends Transaction {
    private final String accountNumber;
    private final int amount;

    public WithdrawMoney(String accountNumber, int amount) {
        this.accountNumber = accountNumber;
        this.amount = amount;
    }

    @Override
    public void updateBalance(Bank bank) {
    	bank.updateBalance(accountNumber, b -> b - amount);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        WithdrawMoney that = (WithdrawMoney) obj;
        return amount == that.amount && Objects.equals(accountNumber, that.accountNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber, amount);
    }

}