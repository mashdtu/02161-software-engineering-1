package dtu.bank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import dtu.bank.transactions.DepositMoney;
import dtu.bank.transactions.InitialBalance;
import dtu.bank.transactions.Transaction;
import dtu.bank.transactions.TransferMoney;
import dtu.bank.transactions.WithdrawMoney;

public class Bank {

    private final Map<String, Account> accounts = new HashMap<>();
    private final List<Transaction> transactions = new ArrayList<Transaction>();

    public String register(String userName, int initialBalance) {
    	var account = new Account(new User(userName),initialBalance);
    	addAccount(account);
        addTransaction(new InitialBalance(account.getAccountId(), initialBalance));
        return account.getAccountId();
    }

	private void addAccount(Account account) {
		accounts.put(account.getAccountId(), account);
	}

    public void withdraw(String accountId, int amount) throws Exception {
        checkForPositiveAmount(amount);
        int newBalance = getBalance(accountId) - amount;
        checkForSufficientFunds(newBalance);
        addTransaction(new WithdrawMoney(accountId, amount));
    }

    public void deposit(String accountId, int amount) throws Exception {
        checkForPositiveAmount(amount);
        var transaction = new DepositMoney(accountId, amount);
        addTransaction(transaction);
    }

    public int getBalance(String accountId) throws Exception {
        if (!accounts.containsKey(accountId)) {
            throw new Exception("Invalid bank account number");
        }
        return accounts.get(accountId).getBalance();
    }

    public void transfer(String senderAccountId, String recipientAccountId, int amount) throws Exception {
        checkForPositiveAmount(amount);
        int newBalance = getBalance(senderAccountId) - amount;
        checkForSufficientFunds(newBalance);
        addTransaction(new TransferMoney(senderAccountId, amount, recipientAccountId));
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    private void checkForSufficientFunds(int newBalance) throws Exception {
        if (newBalance < 0) {
            throw new Exception("Insufficient balance");
        }
    }

    private void checkForPositiveAmount(int amount) throws Exception {
        if (amount <= 0) {
            throw new Exception("Amount must be positive");
        }
    }

	private void addTransaction(Transaction transaction) {
		transactions.add(transaction);
        transaction.updateBalance(this);
	}

	public void updateBalance(String accountNumber, Function<Integer,Integer> updateFunction) {
		var account = accounts.get(accountNumber);
		account.setBalance(updateFunction.apply(account.getBalance()));
	}
}