package dtu.bank;

import java.util.UUID;

public class Account {

	private String accountId;
	private User user;
	private int balance;
	
	public Account(User user, int balance) {
		this.accountId = UUID.randomUUID().toString();
		this.user = user;
		this.balance = balance;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getAccountId() {
		return accountId;
	}

	public User getUser() {
		return user;
	}


}
