package dtu.bank.transactions;

import dtu.bank.Bank;

public abstract class Transaction { 
    public abstract void updateBalance(Bank bank);
}
