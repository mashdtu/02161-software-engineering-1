package dtu.bank;

public record User(String name) {}

