package dtu.bank;

public class BankException extends Exception {

    private final String message;

    public BankException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
