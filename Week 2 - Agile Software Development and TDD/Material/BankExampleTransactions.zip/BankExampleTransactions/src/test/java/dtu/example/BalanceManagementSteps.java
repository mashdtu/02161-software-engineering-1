package dtu.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dtu.bank.Bank;
import dtu.bank.transactions.DepositMoney;
import dtu.bank.transactions.InitialBalance;
import dtu.bank.transactions.Transaction;
import dtu.bank.transactions.TransferMoney;
import dtu.bank.transactions.WithdrawMoney;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BalanceManagementSteps {

    public static final String JOHN_DOE = "John Doe";
    private Bank bank = new Bank(); // Instance of the bank
    private List<Transaction> transactions; // List to hold retrieved transactions
    private Exception lastException; // To store any exception thrown during a step
    private Map<String,String> accounts = new HashMap<>(); // Map user name to account id

    @Given("a registered user with an account balance of {int}")
    public void aRegisteredUserWithAnAccountBalanceOf(Integer balance) {
        String johnDoe = JOHN_DOE;
        var accountNumber = bank.register(johnDoe, balance);
        accounts.put(johnDoe, accountNumber);
    }

    @When("the user withdraws {int}")
    public void whenTheUserWithdraws(Integer amount) throws Exception {
        // Perform the withdrawal operation for the user
        var accountNumber = accounts.get(JOHN_DOE);
        bank.withdraw(accountNumber, amount);
    }

    @Then("the account balance should be {int}")
    public void thenTheAccountBalanceShouldBe(Integer expectedBalance) throws Exception {
        // Verify that the actual balance matches the expected balance
        var accountNumber = accounts.get(JOHN_DOE);
        int actualBalance = bank.getBalance(accountNumber);
        assertEquals(expectedBalance, actualBalance,
                "The account balance is not as expected after withdrawal.");
    }

    @Given("a registered user {string} with an account balance of {int}")
    public void aRegisteredUserWithAnAccountBalanceOf(String name, Integer int1) {
        var accountNumber = bank.register(name, int1);
        accounts.put(name, accountNumber);
    }
    @When("the user {string} withdraws {int}")
    public void theUserWithdraws(String userName, Integer amount) throws Exception {
        // Retrieve the user and perform the withdrawal
        bank.withdraw(accounts.get(userName), amount);
    }

    @Then("the account balance for {string} should be {int}")
    public void theAccountBalanceForShouldBe(String string, Integer int1) throws Exception {
        assertEquals(int1, bank.getBalance(accounts.get(string)));
    }

    @When("the user {string} deposits {int}")
    public void theUserDeposits(String userName, Integer amount) throws Exception {
        // Retrieve the user and perform the deposit
        try {
            bank.deposit(accounts.get(userName), amount);
        } catch (Exception e) {
            lastException = e;
        }
    }

    @When("the user {string} transfers {int} to {string}")
    public void theUserTransfersTo(String senderName, int amount, String recipientName) throws Exception {
        try {
            bank.transfer(accounts.get(senderName), accounts.get(recipientName), amount);
        } catch (Exception e) {
            lastException = e;
        }
    }

    @When("{string} tries to withdraw {int}")
    public void triesToWithdraw(String username, int amount) {
        try {
            bank.withdraw(accounts.get(username), amount);
        } catch (Exception e) {
            lastException = e; // Store the exception to be verified later
        }
    }

    @Then("an error should occur with the message {string}")
    public void anErrorShouldOccurWithTheMessage(String expectedMessage) {
        assertEquals(expectedMessage, lastException.getMessage());
    }

    // Step definition for user registration
    @When("I register with the name {string} and an initial balance of {int}")
    public void iRegisterWithTheNameAndInitialBalance(String name, Integer initialBalance) {
        try {
            String accountNumber = bank.register(name, initialBalance);
            accounts.put(name, accountNumber); // Store the account number for reference
        } catch (Exception e) {
            lastException = e; // Capture any exceptions
        }
    }

    // Step definition for verifying a unique account number is returned
    @Then("I receive a unique bank account number")
    public void iReceiveAUniqueBankAccountNumber() {
        String accountNumber = accounts.get(JOHN_DOE);
        assertNotNull(accountNumber, "Account number should not be null");
    }

    // Step definition for retrieving the user's balance
    @Then("the balance for the bank account is {int}")
    public void theBalanceForTheBankAccountIs(Integer expectedBalance) throws Exception {
        String accountNumber = accounts.get(JOHN_DOE);
        int actualBalance = bank.getBalance(accountNumber);
        assertEquals(expectedBalance, actualBalance,
                "The retrieved balance does not match the expected value");
    }

    // Step definition for invalid account balance retrieval
    @When("I attempt to get the balance for an invalid bank account number {string}")
    public void iAttemptToGetTheBalanceForAnInvalidBankAccountNumber(String invalidAccountNumber) {
        try {
            bank.getBalance(invalidAccountNumber);
        } catch (Exception e) {
            lastException = e; // Capture the exception for verification
        }
    }

    @Then("an error is raised indicating {string}")
    public void anErrorIsRaisedIndicating(String expectedMessage) {
        assertNotNull(lastException, "An exception should have been thrown");
        assertEquals(expectedMessage, lastException.getMessage(),
                "The exception message does not match the expected value");
    }

    // Step to retrieve transactions for a user by their name
    @When("I ask for the transactions of {string}")
    public void iAskForTheTransactionsOf(String userName) {
        transactions = bank.getTransactions(); // Retrieve transaction history
    }

    // Step to verify a specific transaction exists in the user's transaction history
    @Then("I should see a transaction with type {string} and amount {int}")
    public void iShouldSeeATransactionWithTypeAndAmount(String type, Integer amount) {
        assertNotNull(transactions, "Transaction should not be null");
        var expectedTransaction = createTransactionRecord(JOHN_DOE, type, amount,null);
        assertEquals(expectedTransaction, transactions.get(0), "Expected transaction not found in the transaction history.");
    }

    private Transaction createTransactionRecord(String fromName, String type, int amount, String toName) {
        String from = null;
        String to = null;
        if (fromName != null) {
            from = accounts.get(fromName);
        }
        if (toName != null) {
            to = accounts.get(toName);
        }
        return switch (type) {
            case "initial" -> new InitialBalance(from,amount);
            case "deposit" -> new DepositMoney(from,amount);
            case "withdrawal" -> new WithdrawMoney(from,amount);
            case "transfer" -> new TransferMoney(from,amount,to);
            default -> throw new IllegalArgumentException("Unknown transaction type: " + type);
        };
    }


    @Then("I should see the transactions in the following order:")
    public void iShouldSeeTheTransactionsInTheFollowingOrder(io.cucumber.datatable.DataTable dataTable) {
        // Convert the DataTable into a list of maps for easier processing
        List<Map<String, String>> expectedTransactionRows = dataTable.asMaps(String.class, String.class);
        assertNotNull(transactions, "Transaction list should not be null"); // Ensure transactions list is not null

        // Ensure the size matches the actual transactions list
        assertEquals(expectedTransactionRows.size(), transactions.size(), "Transaction count mismatch.");

        // Iterate through each expected transaction, create them, and compare using .equals

        var expectedTransactions = new ArrayList<Transaction>();
        for (int i = 0; i < expectedTransactionRows.size(); i++) {
            var row = expectedTransactionRows.get(i);

            // Extract values from the row
            String type = row.get("Type"); // Transaction type
            var amountString = row.get("Account");
            int amount = 0;
            if (amountString != null) {
                amount = Integer.parseInt(row.get("Amount")); // Transaction amount
            }
            String toName = row.get("User"); // User-readable account name (Sender or recipient)
            String fromName = row.get("Account");

            // Create the expected transaction record using the utility method
            expectedTransactions.add(createTransactionRecord(fromName, type, amount,toName));
        }
        assertEquals(expectedTransactions, transactions);
    }

    @When("I ask for the transactions of the bank")
    public void iAskForTheTransactionsOfTheBank() {
        transactions = bank.getTransactions();
    }
}
