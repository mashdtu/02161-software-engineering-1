Feature: Bank account registration and balance retrieval
	As a User
	I want to register with the bank
	To be able to know what my balance is

	Scenario: Successfully registering a new user and checking balance
		When I register with the name "John Doe" and an initial balance of 1000
		Then I receive a unique bank account number
		And the balance for the bank account is 1000

	Scenario: Attempting to retrieve a balance for an invalid bank account number
		When I attempt to get the balance for an invalid bank account number "12345"
		Then an error is raised indicating "Invalid bank account number"