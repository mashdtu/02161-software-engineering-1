Feature: Bank transaction history
  As a user
  I want to see my transaction history
  So that I know all deposits and withdrawals made on my account

  Scenario: User sees an initial transaction in history after account registration
    Given a registered user "John Doe" with an account balance of 1000
    When I ask for the transactions of the bank
    Then I should see a transaction with type "initial" and amount 1000

  Scenario: Checking transaction order for initial deposit, deposit, and withdrawal
    Given a registered user "John Doe" with an account balance of 1000
    When the user "John Doe" deposits 500
    And the user "John Doe" withdraws 300
    Then the account balance for "John Doe" should be 1200
    And I ask for the transactions of the bank
    Then I should see the transactions in the following order:
      | Account  | Type       | Amount |
      | John Doe | initial    | 1000   |
      | John Doe | deposit    | 500    |
      | John Doe | withdrawal | 300    |

  Scenario: Money transfer between two users
    Given a registered user "Alice" with an account balance of 2000
    And a registered user "Bob" with an account balance of 1000
    When the user "Alice" transfers 500 to "Bob"
    Then the account balance for "Alice" should be 1500
    And the account balance for "Bob" should be 1500
    And I ask for the transactions of the bank
    Then I should see the transactions in the following order:
      | Account | Type     | Amount | User |
      | Alice   | initial  | 2000   |      |
      | Bob     | initial  | 1000   |      |
      | Alice   | transfer | 500    | Bob  |
